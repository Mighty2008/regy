
import * as firebase from "firebase";
require("@firebase/firestore");



const firebaseConfig = {
    apiKey: "AIzaSyDnOQVpSUz15n25tw3AFrMNxL60Z0e87QA",
    authDomain: "story-hub-b58b1.firebaseapp.com",
    projectId: "story-hub-b58b1",
    storageBucket: "story-hub-b58b1.appspot.com",
    messagingSenderId: "505935381194",
    appId: "1:505935381194:web:5091d309cbd83df0772a33"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);


  export default firebase.firestore();